package page;

import base.TestBase;

public class HomePage extends TestBase {

	
}
