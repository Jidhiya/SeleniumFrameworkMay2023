package page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import base.TestBase;

public class LoginPage extends TestBase{

	By username = By.xpath("//input[@name='username']");
	By password = By.xpath("");
	
	By login = By.cssSelector("button.orangehrm-login-button");
	String user = "Admin";
	String pass = "admin123";
	
	
	LoginPage() {
		
		// TODO Auto-generated constructor stub
	}
	
	public void login()
	{
		driver.findElement(username).sendKeys(user);
		driver.findElement(password).sendKeys(pass);
	}
	
	

}
